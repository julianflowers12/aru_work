Licence: Creative Commons, with Attribution, Non-commercial v4.0 (CC-BY-NC). See here for full details of what is permitted: https://creativecommons.org/licenses/by-nc/4.0/

Citation: Gillings, S., Balmer, D.E., Caffrey, B.J., Downie, I.S., Gibbons, D.W., Lack, P.C., Reid, J.B., Sharrock, J.T.R., Swann, R.L. & Fuller, R.J. (in press) Breeding and wintering bird distributions in Britain and Ireland from citizen science bird atlases. Global Ecology and Biogeography.

BTO 
02 February 2019

